//
//  JSCocoa.h
//  JSCocoa
//
//  Created by Patrick Geiller on 16/12/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//


#define JSCOCOA
#import "JSCocoaController.h"